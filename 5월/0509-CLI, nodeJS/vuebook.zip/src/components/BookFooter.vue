<template>
    <div>
        <h3>made by SSAFY</h3>
    </div>
</template>

<script>
export default {
    name: 'BookFooter'
}
</script>

<style scoped>
</style>