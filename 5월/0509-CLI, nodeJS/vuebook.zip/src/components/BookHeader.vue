<template>
    <div class="header">
        <a href="index.html"> <img src="../assets/ssafy_logo.png" class="ssafy_logo" /></a>
        <p class="logo">도서관리</p>
    </div>
</template>

<script>
export default {
    name: 'BookHeader'
}
</script>

<style scoped>
</style>